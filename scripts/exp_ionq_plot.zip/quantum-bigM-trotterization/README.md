# Alleviating the quantum Big-M problem

This repository contains an example of the Hamiltonian generation, Trotterization and parser for IonQ deployment of the results presented in the paper.
